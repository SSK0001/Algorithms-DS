def hellofunction(text):
    """
    :param text: some text
    :return: This function returns the sample "hello world" with the text.
    """
    print("Hello world ",text)