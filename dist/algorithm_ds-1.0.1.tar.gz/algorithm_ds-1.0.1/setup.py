from distutils.core import setup

setup(
    name='algorithm_ds',
    version='1.0.1',
    packages=[''],
    url='https://github.com/SSK0001/Algorithms-DS',
    license='MIT License',
    author='Santhosh ',
    author_email='santhoshksuram@gmail.com',
    description='Repository contains the solutions to most common CS Algorithm problems.'
)
